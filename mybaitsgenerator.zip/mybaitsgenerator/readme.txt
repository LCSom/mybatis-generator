 oracle�Ķ�
 <selectKey resultType="java.lang.Long" keyProperty="id" order="BEFORE" >
      select sequence.NEXTVAL FROM DUAL
 </selectKey>